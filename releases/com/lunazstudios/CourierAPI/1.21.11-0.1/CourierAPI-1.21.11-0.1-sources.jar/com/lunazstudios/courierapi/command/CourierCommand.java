package com.lunazstudios.courierapi.command;

import com.lunazstudios.courierapi.api.CourierAPI;
import com.lunazstudios.courierapi.api.Notification;
import com.lunazstudios.courierapi.server.NotificationDefinitions;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.Optional;
import net.minecraft.class_12087;
import net.minecraft.class_12090;
import net.minecraft.class_12094;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

/**
 * Registers the {@code /courier} command tree (requires permission level 2).
 *
 * <ul>
 *   <li>{@code /courier send <id>} — broadcasts the notification with the given ID to all online players.</li>
 *   <li>{@code /courier reload}   — reloads {@code couriernotifications.json} from disk.</li>
 * </ul>
 */
public final class CourierCommand {

    private CourierCommand() {}

    /** Registers all subcommands into the given dispatcher. */
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("courier")
                .requires(class_2170.method_71774(
                        new class_12090.class_12092(new class_12087.class_12089(class_12094.field_63198))))

                .then(class_2170.method_9247("send")
                    .then(class_2170.method_9244("id", StringArgumentType.word())
                        .suggests((ctx, builder) -> {
                            NotificationDefinitions.getIds().forEach(builder::suggest);
                            return builder.buildFuture();
                        })
                        .executes(ctx -> {
                            String id = StringArgumentType.getString(ctx, "id");
                            Optional<Notification> opt = NotificationDefinitions.get(id);

                            if (opt.isEmpty()) {
                                ctx.getSource().method_9213(class_2561.method_43470(
                                        "[CourierAPI] ID '" + id + "' not found. "
                                        + "Check couriernotifications.json or run /courier reload."));
                                return 0;
                            }

                            CourierAPI.broadcast(ctx.getSource().method_9211(), opt.get());
                            ctx.getSource().method_9226(() -> class_2561.method_43470(
                                    "[CourierAPI] Notification '" + id + "' sent to all online players."),
                                    true);
                            return 1;
                        })
                    )
                )

                .then(class_2170.method_9247("reload")
                    .executes(ctx -> {
                        NotificationDefinitions.reload(ctx.getSource().method_9211());
                        ctx.getSource().method_9226(() -> class_2561.method_43470(
                                "[CourierAPI] couriernotifications.json reloaded."),
                                true);
                        return 1;
                    })
                )
        );
    }
}
