package com.lunazstudios.courierapi.network;

import com.lunazstudios.courierapi.Courierapi;
import com.lunazstudios.courierapi.api.Notification;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** S2C packet that carries a {@link Notification} from the server to a client. */
public record NotificationPacket(Notification notification) implements class_8710 {

    public static final class_8710.class_9154<NotificationPacket> ID =
            new class_8710.class_9154<>(class_2960.method_60655(Courierapi.MODID, "notification"));

    public static final class_9139<class_9129, NotificationPacket> CODEC =
            class_9139.method_56434(
                    Notification.PACKET_CODEC.method_56430(),
                    NotificationPacket::notification,
                    NotificationPacket::new
            );

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
